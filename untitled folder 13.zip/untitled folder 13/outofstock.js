function myFunction(){
    document.getElementById("secret").innerHTML="Lol, Try Again Later";
}